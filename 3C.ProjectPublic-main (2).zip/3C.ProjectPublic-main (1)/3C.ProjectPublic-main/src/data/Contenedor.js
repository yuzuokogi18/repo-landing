
const Contenedor = {
    products: [
        {
            text: '© 2024 Restaurante Raudales. Todos los derechos reservados.',
           
        }
    ]
};


export default Contenedor;
