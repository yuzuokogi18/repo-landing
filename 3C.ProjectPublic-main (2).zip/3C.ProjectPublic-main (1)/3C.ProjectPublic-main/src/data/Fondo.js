const Fondo = {
    items: [
        {
            image: 'xd.png'
        }
    ],
    items2: [
        {
            text: 'Menu'
        }
    ]
};

export default Fondo;
